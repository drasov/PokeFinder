import Home from "../components/home";

export default Home